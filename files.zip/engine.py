import math
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.decomposition import PCA
import yfinance as yf
import sys
import pandas_ta as ta
import talib
import matplotlib.pyplot as plt
import warnings
import pandas as pd
import neat
from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)



if __name__ == "__main__":
    
        
        