from __future__ import print_function
import math
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.decomposition import PCA
import yfinance as yf
import sys
import pandas_ta as ta
import talib
import matplotlib.pyplot as plt
import warnings
import pandas as pd
import neat
from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)
from get_data import Get_data

import os
import neat
import visualize
from trader import Trader


def eval_genomes(genomes, config):
    stock = 'V'
    tickers = [stock]
    data = Get_data(tickers,
                    start_date="2017-01-01", 
                    end_date="2018-01-01",
                    eval_year='2019')
    
    data.download()
    train = data.train
    test = data.test
    nets = []
    traders = []
    gnomes = []
    for df in test:
        df.reset_index(inplace=True)
        
    for genome_id, genome in genomes:
        genome.fitness = 0.0
        net = neat.nn.FeedForwardNetwork.create(genome, config)
        nets.append(net)
        traders.append(Trader(50000))
        gnomes.append(genome)

    for x, trader in enumerate(traders): # traders in generation
        output = nets[traders.index(trader)].activate(train[0].T)
        print(output[0])
                
                
          




def run(config_file):
    # Load configuration.
    config = neat.config.Config(neat.DefaultGenome, neat.DefaultReproduction,

                                neat.DefaultSpeciesSet, neat.DefaultStagnation,

                                config_file)

    p = neat.Population(config)
    p.add_reporter(neat.StdOutReporter(True))
    stats = neat.StatisticsReporter()
    p.add_reporter(stats)
    winner = p.run(eval_genomes, 500)
    print('\nBest genome:\n{!s}'.format(winner))

if __name__ == '__main__':
    # Determine path to configuration file. This path manipulation is
    # here so that the script will run successfully regardless of the
    # current working directory.
    local_dir = os.path.dirname(__file__)
    config_path = os.path.join(local_dir, r'C:\Users\Vnixo\OneDrive\Desktop\ML_projects\gen_algo_stock_market\Dev\config.txt')
    run(config_path)


    
